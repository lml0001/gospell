#!/bin/sh

echo "Loading Program"

cd /tmp/ko_gos/ && ./load3519v101 -a -sensor0 bt1120 -sensor1 bt1120 -osmem 192 -offline

/tmp/main
