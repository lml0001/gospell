#!/bin/sh

echo "Loading Program"

cd /tmp/ko_gos/ && ./load3519v101 -a -sensor0 ov4689 -sensor1 ov4689 -osmem 192 -offline

/tmp/main
