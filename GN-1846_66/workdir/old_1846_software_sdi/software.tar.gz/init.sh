#!/bin/sh

echo "Loading Program"

cd /tmp/ko_gos/ && ./load3531a -a -osmem 192

/tmp/main
